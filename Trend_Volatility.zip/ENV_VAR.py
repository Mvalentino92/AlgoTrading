# API
APCA_API_BASE_URL='https://paper-api.alpaca.markets'
APCA_API_KEY_ID='PKTTXBWKZZXVMP5JXVPO'
APCA_API_SECRET_KEY='0CgYbN2tp1AtWyjCrgysWvEviMF1g4tw31wA2YXZ'
AV_API_KEY_ID='F1QACIJR7DUPCA2T'
APCA_MAX_CALLS = 200
AV_MAX_CALLS = 5

# Indices for data
OPEN_INDEX = 0
HIGH_INDEX = 1
LOW_INDEX = 2
CLOSE_INDEX = 3
VOLUME_INDEX = 4
METRICS = ['Open','High','Low','Close','Volume']

# For historical data (Set end to something very close to current day, like a week before)
DATE_START = '2016-01-01'
DATE_END = '2020-08-05'

# How many values we want to have to play with at LEAST
MIN_NUM_DAYS = 100

