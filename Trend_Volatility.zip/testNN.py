from ENV_VAR import *
from IMPORTS import *
from utils import *
from NN import *

api = tradeapi.REST(APCA_API_KEY_ID,APCA_API_SECRET_KEY,APCA_API_BASE_URL,'v2')
av = api.alpha_vantage

extrapolate(api,av,['ROST','VERY','ATVI','CTAS','EXPE'])
