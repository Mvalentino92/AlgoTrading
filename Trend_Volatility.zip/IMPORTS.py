import alpaca_trade_api as tradeapi
import numpy as np
import random
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
import time
from collections import deque
import pandas as pd
import scipy.optimize as opt
