from ENV_VAR import *
from IMPORTS import *
from utils import *
from NN import *

# Get APIS
api = tradeapi.REST(APCA_API_KEY_ID,APCA_API_SECRET_KEY,APCA_API_BASE_URL,'v2')
av = api.alpha_vantage

# Get tradable symbols
symbols = filter_stocks(api,av,n=150,t=15,exchange='NASDAQ')

# Get two weight vectors
w1 = get_weights(lambda x: x**2,100,k=0.2)
w2 = np.array([0.25,0.50,0.25])

# Get recommended to buy
print('Getting recos')
recos = recommend_to_buy(api,av,symbols,w1,w2)

# Take the top 5 from recos, and use that
top_recos = recos[0:5]

# *** Begin to test trading, set tolerances and amount of money we have ***
cash = 2500
ptol = 0.035
ltol = -0.05

# Do each stock one at a time, and get the intraday data for that stock (filter intraday to start at date beyond date_end)
calls = 0
for symbol in top_recos:

    # Intraday
    calls = (calls + 1) % AV_MAX_CALLS
    intraday = av.intraday_quotes(symbol,'1min')
    dates = np.array(list(map(lambda x: x.split()[0],intraday.keys()))[::-1]) # In reverse
    bools = dates > DATE_END # Logical indexing
    values = np.array([list(sample.values()) for sample in list(intraday.values())],dtype=np.float)[bools,OPEN_INDEX] # Ugh, double dict stuff

    # Buy at this first price, (always buy 1/3 of what you can afford)
    buy_percent = 1/3/len(top_recos)
    buy_price = values[0]
    shares = divmod(cash*buy_percent,buy_price)[0]
    cash -= shares*buy_price

    # Now go through these values and check if we need to buy or sell
    has_sold = False
    for sample in values:

        # Check to see if sell
        pl = (sample*shares - buy_price*shares)/(buy_price*shares)
        if pl <= ltol:
            cash += sample*shares
            print('SOLD {} at a loss of {}'.format(symbol,np.around(pl,decimals=5)))
            has_sold = True
        if pl > ptol:
            cash += sample*shares
            print('SOLD {} at a profit of {}'.format(symbol,np.around(pl,decimals=5)))
            has_sold = True

        if has_sold:
            break

    if not calls:
        time.sleep(60)

    print('Total cash:',cash)
