from ENV_VAR import *
from IMPORTS import *
from utils import *
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from keras.models import Model
from keras.layers import Input
from keras.layers import Dense
from keras.layers import Dropout
import sklearn.metrics as mt

# Create function to accept a symbol, and estimate the price with machine learning
# Note, any stocks in this list, (if same date start and date end are used) have sufficient data, governed by MIN_NUM_DAYS
def extrapolate(api,av,symbols,date_start=DATE_START,date_end=DATE_END,num_samples=10):

    # Same flavor as recommend, return a list of recommended
    recommended = []

    # Begin to look up historical data for stocks
    calls = 0
    elasped_time = 0
    for symbol in symbols:

        # Star time
        start_time = time.time()

        # Get the np.array of all the values for the historical data
        calls = (calls + 1) % AV_MAX_CALLS  # Put before so it still increments if we exit try clause
        hist = av.historic_quotes(symbol)
        hist = np.array([list(hist.get(i).values()) for i in hist if date_start <= i <= date_end],
                        dtype=np.float)[::-1]


        # Trim the hist to the past MIN_NUM_DAYS (again, all them at least have that many)
        hist = hist[-MIN_NUM_DAYS:]

        # Grab the input (all features, in strides on num_samples
        indices = list(zip(range(0, len(hist) - num_samples), range(num_samples, len(hist))))
        X = np.array(list(map(lambda x: np.concatenate(hist[x[0]:x[1],:-1]),indices)))

        # Grab the output, which is the value after each stride
        y = hist[num_samples:,:-1]

        # Train test split
        X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=8/len(X),shuffle=False)

        # Use a standard scaler
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

        # Create the neural net layers
        input_ = Input(shape=(4*num_samples,))
        layer1 = Dense(1024,activation='relu')(input_)
        layer2 = Dense(1024,activation='relu')(layer1)
        drop = Dropout(0.5)(layer2)
        layer3 = Dense(512,activation='relu')(drop)
        layer4 = Dense(512,activation='relu')(layer3)
        output_ = Dense(4)(layer4)

        # Create the model
        model = Model(inputs=input_,outputs=output_)

        # Compile
        model.compile(optimizer='Adam',loss='mean_squared_error')

        # Run and fit the model
        w = get_weights(lambda x: x**2,len(X_train),k=0.45)
        model.fit(X_train,y_train,batch_size=32,epochs=100,sample_weight=w,verbose=0)

        # Test on the test data
        y_hat = model.predict(X_test)

        # Plot all the values against each other for y ad y_hat
        # fig,axs = plt.subplots(4,figsize=(5,20))
        # for i in range(4):
        #     tru = y_test[:,i]
        #     pred = y_hat[:,i]
        #     t = np.arange(len(tru))
        #     axs[i].plot(t,tru)
        #     axs[i].plot(t,pred)
        #     axs[i].title.set_text(METRICS[i])
        #     axs[i].legend(('True','Predict'))
        # fig.suptitle(symbol)
        # plt.show()

        # Errors
        perr = mape(y_test,y_hat)

        # If the error is less than threshhold, we can retrain and evaluate this stock
        if perr > 0.08:
            end_time = time.time()
            elasped_time += end_time - start_time
            sleep_time = 0 if elasped_time > 60 else 60 - elasped_time
            if not calls:
                elasped_time = 0
                time.sleep(sleep_time)
            continue

        # TODO: Begin to use all the data to train and then predict 1 weeks worth of daily values.
        # TODO: Observe these daily values, and see if they are increasing (All higher than buy price?)
        # TODO: Remember, will have to feed output as new input after each prediction. That's why only 7 days.
        # TODO: Will use these predicted values, and the intraday volatility of the last REAL days to sell selling thresholds.

        # First, retrain model using all the data
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        w = get_weights(lambda x: x ** 2, len(X), k=0.45)
        model.fit(X, y, batch_size=32, epochs=50, sample_weight=w,verbose=0)

        # Get the accuracy of this, as a final check that it's not all of a sudden terrible
        y_hat = model.predict(X)

        # fig,axs = plt.subplots(4,figsize=(5,20))
        # for i in range(4):
        #     tru = y[:,i]
        #     pred = y_hat[:,i]
        #     t = np.arange(len(tru))
        #     axs[i].plot(t,tru)
        #     axs[i].plot(t,pred)
        #     axs[i].title.set_text(METRICS[i])
        #     axs[i].legend(('True','Predict'))
        # fig.suptitle(symbol)
        # plt.show()

        # Error
        perr = mape(y,y_hat)
        if perr > 0.08:
            end_time = time.time()
            elasped_time += end_time - start_time
            sleep_time = 0 if elasped_time > 60 else 60 - elasped_time
            if not calls:
                elasped_time = 0
                time.sleep(sleep_time)
            continue

        # Now we are finally good, and ready to actually predict values
        predictions = []
        x = scaler.transform(np.concatenate(hist[-num_samples:,:-1]).reshape(1,-1)) # This is the last (open,low,high,close) we have
        for i in range(1,8):
            p = model.predict(x).reshape(-1,)
            predictions.append(p)
            x = np.concatenate(hist[-num_samples+i:, :-1])
            x = np.concatenate((x,np.concatenate(predictions)))
            x = scaler.transform(x.reshape(1,-1))

        # Grab the closing values only
        predictions = np.array(predictions)[:,-1] # Close is now last

        # Score these as both trend and raw value being higher
        last_close = hist[-1,CLOSE_INDEX]
        raw_score = np.mean(predictions - last_close)

        # Get a score for the upward trends, using simple raw gradient
        grad_score = np.mean(np.gradient(predictions))

        # Average raw and grad score (don't care if on different magnitudes right now)
        score = (raw_score + grad_score)/2

        # If the score is positive, this stock passes the test, add it to the list along
        if score > 0:
            recommended.append(symbol)

        # Sleep
        end_time = time.time()
        elasped_time += end_time - start_time
        sleep_time = 0 if elasped_time > 60 else 60 - elasped_time
        if not calls:
            elasped_time = 0
            time.sleep(sleep_time)

        # Show the predictions and the last_close, and plot
        # print('Last close {} and predictions are: {}'.format(last_close,predictions))
        # plt.scatter([0],[last_close])
        # plt.plot(np.arange(7),predictions)
        # plt.title('Score: {}'.format(np.around(score,decimals=5)))
        # plt.show()

    time.sleep(60)
    return recommended
